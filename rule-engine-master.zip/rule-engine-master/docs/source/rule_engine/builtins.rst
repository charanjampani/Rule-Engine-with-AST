:mod:`builtins`
===============

.. module:: rule_engine.builtins
   :synopsis:

This module contains the class which defines the builtin values for the engine.

.. autoclass:: Builtins
   :members:
   :show-inheritance:
   :special-members: __init__
   :undoc-members:
