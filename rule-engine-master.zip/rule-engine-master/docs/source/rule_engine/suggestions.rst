:mod:`suggestions`
==================

.. module:: rule_engine.suggestions
   :synopsis:

.. versionadded:: 3.2.0

This module contains the helper functions needed to make suggestions when errors occur.

Functions
---------

.. autofunction:: suggest_symbol